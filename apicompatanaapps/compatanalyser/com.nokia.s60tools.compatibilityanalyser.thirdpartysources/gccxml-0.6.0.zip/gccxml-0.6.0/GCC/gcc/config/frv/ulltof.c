float __ulltof (unsigned long long a)
{
  return a;
}
